import sys,json,hashlib,pathlib,numpy as np
sys.path.insert(0,'/workspace/scratch/3321ed1a6be1/sports-model')
from pipelines.cards.adapters import nfl
from models.nfl.contextual.runtime import run
root=pathlib.Path('/workspace/scratch/3321ed1a6be1/verification-run/2026_01_DEN_KC')
b=json.loads((root/'forecast.json').read_text());p=nfl._package();e=b['event'];c=nfl.build_context([e],b['cutoff_utc']);x=p['event_inputs'][e['event_id']]
r,w,s=run(c['model'],c['recovered'],x['base'],x['context'],e,b['cutoff_utc'],100000,model_id=b['model_id'])
assert r==b
assert np.array_equal(w,np.load(root/'winner_draws.npy'))
assert np.array_equal(s,np.load(root/'score_draws.npy'))
count=0
for manifest in root.rglob('manifest.json'):
 m=json.loads(manifest.read_text())
 print(manifest.relative_to(root),list(m))
 for name,digest in m.items():
  if isinstance(digest,str) and len(digest)==64 and (manifest.parent/name).is_file():
   assert hashlib.sha256((manifest.parent/name).read_bytes()).hexdigest()==digest;count+=1
print(json.dumps({'bundle_exact':True,'winner_draws_exact':True,'score_draws_exact':True,'manifest_files_verified':count,'cutoff':b['cutoff_utc'],'feature_count':len(b['features']),'simulations':len(w)}))
