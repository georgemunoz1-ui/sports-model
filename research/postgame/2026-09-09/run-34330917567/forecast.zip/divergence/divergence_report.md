# MLB Analytic-vs-Simulation Divergence — 2026-09-09

Forecasts analyzed: **15**

| Category | Count |
|---|---:|
| CRITICAL | 1 |
| SEVERE | 2 |
| MODERATE | 4 |
| NONE | 8 |

## Per-game

| Game | Analytic P | Stochastic Sim P | Gap | Category | Margin | Total | Normal-margin candidate |
|---|---:|---:|---:|---|---:|---:|---:|
| Minnesota Twins @ Detroit Tigers | 56.4% | 54.4% | +1.98 pp | NONE | 0.48 | 8.47 | 53.2% |
| Toronto Blue Jays @ Athletics | 58.6% | 50.6% | +7.98 pp | MODERATE | -0.76 | 11.95 | 53.9% |
| St. Louis Cardinals @ San Francisco Giants | 59.0% | 56.2% | +2.84 pp | NONE | -0.65 | 7.75 | 54.7% |
| Washington Nationals @ San Diego Padres | 54.0% | 52.5% | +1.58 pp | NONE | -0.31 | 8.82 | 52.0% |
| Texas Rangers @ Seattle Mariners | 55.6% | 52.8% | +2.77 pp | NONE | -0.39 | 7.52 | 52.8% |
| Cleveland Guardians @ Baltimore Orioles | 50.9% | 50.6% | +0.24 pp | NONE | -0.06 | 7.80 | 50.5% |
| Houston Astros @ Philadelphia Phillies | 59.8% | 55.7% | +4.10 pp | MODERATE | 0.73 | 8.35 | 56.1% |
| New York Mets @ Miami Marlins | 59.8% | 56.2% | +3.64 pp | NONE | 0.70 | 7.54 | 55.1% |
| Los Angeles Angels @ Boston Red Sox | 69.0% | 58.0% | +11.03 pp | SEVERE | 1.42 | 8.01 | 59.7% |
| Colorado Rockies @ New York Yankees | 62.9% | 53.2% | +9.69 pp | SEVERE | 1.08 | 10.70 | 56.0% |
| Tampa Bay Rays @ Atlanta Braves | 51.0% | 48.8% | +2.19 pp | NONE | -0.08 | 8.39 | 50.6% |
| Arizona Diamondbacks @ Kansas City Royals | 61.7% | 54.6% | +7.14 pp | MODERATE | 0.95 | 9.81 | 55.3% |
| Pittsburgh Pirates @ Chicago White Sox | 52.6% | 49.1% | +3.53 pp | NONE | -0.19 | 8.50 | 51.5% |
| Chicago Cubs @ Milwaukee Brewers | 62.2% | 56.1% | +6.10 pp | MODERATE | 0.93 | 8.57 | 57.5% |
| Cincinnati Reds @ Los Angeles Dodgers | 78.1% | 61.9% | +16.19 pp | CRITICAL | 2.23 | 8.19 | 64.8% |

## Correlations with absolute divergence

| Feature | Pearson r |
|---|---:|
| projected_total | +0.318 |
| abs_projected_margin | +0.947 |
| favorite_analytic_p | +0.925 |
| gamma_dispersion_mean | +0.044 |
| starter_workload_variance | -0.087 |
| bullpen_share_mean | -0.113 |
| park_factor | +0.204 |
| extra_inning_probability | -0.307 |

## Multivariable debug regression

Status: **DEBUG_SAMPLE_ONLY** · n=15 · R²=0.9492613789639086

> This is a debugging sample. Do not treat one slate as calibration evidence.

## Ablation interpretation

- A isolates fixed-rate independent Poisson.
- B adds Gamma run-rate overdispersion while holding starter workload fixed.
- C is explicitly unavailable because the current engine has no shared run-environment component.
- D adds starter-workload randomness.
- E is the full current engine; it currently equals D because bullpen sequencing is not modeled.

**No sportsbook prices or EV calculations are included.**
