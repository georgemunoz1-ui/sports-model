# CFB Diagnostic Card — 2026-11-10

Pregame coverage: **100.0%** · Action authority: **OFF**
Prospective grading eligible: **0**

## Point-in-time provenance

- PIT status: **PIT_ORDERED**
- Requested cutoff: `2026-11-10T13:43:45.596253+00:00`
- Actual live-fetch vintage proxy: `2026-11-10T12:38:04.761187Z`
- Fetch-to-request delta: **-1h 05m 41s**
- Replay supported: **false**
- Vintage basis: `RETAINED_SOURCES_AND_FROZEN_TRANSFORM`

> **PIT WARNING:** this diagnostic card must not be represented as an exact requested-cutoff replay.

**Consumed-state and model integrity — diagnostic, not certification.**
State age uses consumed results; a recent fetch is not a state refresh. Margins below are home minus away.

| Game | Consumed state / age at cutoff | Numerical use | Margin head / sibling distribution | Review |
|---|---|---|---|---|
| Kent State @ Bowling Green | away: UNKNOWN; home: UNKNOWN; CONSUMED_STATE_RECEIPT_ABSENT | INPUT_PRESENT_USE_UNPROVEN; player/goalie effect not demonstrated | +4.80 / UNKNOWN | No named flag established |
| Western Michigan @ Akron | away: UNKNOWN; home: UNKNOWN; CONSUMED_STATE_RECEIPT_ABSENT | INPUT_PRESENT_USE_UNPROVEN; player/goalie effect not demonstrated | -19.21 / UNKNOWN | No named flag established |
| Ohio @ Miami (OH) | away: UNKNOWN; home: UNKNOWN; CONSUMED_STATE_RECEIPT_ABSENT | INPUT_PRESENT_USE_UNPROVEN; player/goalie effect not demonstrated | -6.19 / UNKNOWN | No named flag established |

Input binding alone does not prove numerical use. Review flags do not change forecasts, select a side, or establish calibration.

**Selected default:** cfb.fbs.elo_form_logit_ridge.v1_0.shadow · BASELINE_VALIDATED_DEFAULT
Pooled chronological evaluation passes; season openers have a separate selected profile. V2 remains a challenger.

| Game | Tier | Dose | Winner | Analytic P | Stochastic Sim P | Gap | Divergence | Margin | Total | Grade | Warnings |
|---|---|---:|---|---:|---:|---:|---|---:|---:|---|---|
| Kent State @ Bowling Green | REDUCED | 0.00 | Bowling Green | 62.8% | 62.6% | +0.20 pp | NONE | 4.798437645985379 | None | INELIGIBLE | TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM, CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED, FBS_VS_FBS_ONLY, NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM, NO_WAGERING_AUTHORITY, VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION, ROSTER:ACQUIRE_REQUIRED, FULL_ROSTER_IMPACTS_NOT_APPLIED |
| Western Michigan @ Akron | REDUCED | 0.00 | Western Michigan | 88.3% | 88.3% | +0.02 pp | NONE | 19.21015872151521 | None | INELIGIBLE | TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM, CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED, FBS_VS_FBS_ONLY, NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM, NO_WAGERING_AUTHORITY, VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION, ROSTER:ACQUIRE_REQUIRED, FULL_ROSTER_IMPACTS_NOT_APPLIED |
| Ohio @ Miami (OH) | REDUCED | 0.00 | Ohio | 65.3% | 65.2% | +0.05 pp | NONE | 6.1862508652577555 | None | INELIGIBLE | TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM, CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED, FBS_VS_FBS_ONLY, NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM, NO_WAGERING_AUTHORITY, VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION, ROSTER:ACQUIRE_REQUIRED, FULL_ROSTER_IMPACTS_NOT_APPLIED |

## Missingness change receipts

### Kent State @ Bowling Green (CFB:401866459)

HOLD_PENDING_SCOPE_REVIEW · FITTED_HEADS_REPLAYED · PAIRED_DIAGNOSTIC

| Arm / head | Attribution units | Sporting inputs | Missingness / imputation | Model / version | Unresolved / mixed | Reporting state |
| --- | --- | --- | --- | --- | --- | --- |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / margin | points | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / winner | home_log_odds | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |

margin: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

winner: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

Contributions use the stated fitted-head units; home_log_odds are not probability points. Mixed or unresolved terms are not allocated to sporting observations.

Nonlinear output link is not allocated to individual inputs

Model/version: SAME_FITTED_PARAMETERS

Simulation (separate): named outcome Bowling Green P 0.6287466666666667 → Bowling Green P 0.6262466666666666.

Before/after simulation outputs do not isolate sampling noise when inputs or laws change. Perturbations are diagnostic experiments, not established sporting counterfactuals.

### Western Michigan @ Akron (CFB:401866458)

HOLD_PENDING_SCOPE_REVIEW · FITTED_HEADS_REPLAYED · PAIRED_DIAGNOSTIC

| Arm / head | Attribution units | Sporting inputs | Missingness / imputation | Model / version | Unresolved / mixed | Reporting state |
| --- | --- | --- | --- | --- | --- | --- |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / margin | points | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / winner | home_log_odds | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |

margin: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

winner: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

Contributions use the stated fitted-head units; home_log_odds are not probability points. Mixed or unresolved terms are not allocated to sporting observations.

Nonlinear output link is not allocated to individual inputs

Model/version: SAME_FITTED_PARAMETERS

Simulation (separate): named outcome Western Michigan P 0.8832866666666667 → Western Michigan P 0.8826133333333334.

Before/after simulation outputs do not isolate sampling noise when inputs or laws change. Perturbations are diagnostic experiments, not established sporting counterfactuals.

### Ohio @ Miami (OH) (CFB:401866460)

HOLD_PENDING_SCOPE_REVIEW · FITTED_HEADS_REPLAYED · PAIRED_DIAGNOSTIC

| Arm / head | Attribution units | Sporting inputs | Missingness / imputation | Model / version | Unresolved / mixed | Reporting state |
| --- | --- | --- | --- | --- | --- | --- |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / margin | points | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |
| cfb.fbs.elo_form_logit_ridge.v1_0.shadow / winner | home_log_odds | +0 | +0 | SAME_FITTED_PARAMETERS | +0 | Not assessed |

margin: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

winner: output-scale interaction +0; method FIXED_MODEL_FOUR_CORNERS; complete True.

Contributions use the stated fitted-head units; home_log_odds are not probability points. Mixed or unresolved terms are not allocated to sporting observations.

Nonlinear output link is not allocated to individual inputs

Model/version: SAME_FITTED_PARAMETERS

Simulation (separate): named outcome Ohio P 0.6522266666666667 → Ohio P 0.6521600000000001.

Before/after simulation outputs do not isolate sampling noise when inputs or laws change. Perturbations are diagnostic experiments, not established sporting counterfactuals.


## Input, scenario and decision disclosures

Research only. PASS describes wagering disposition, not a failed prediction.

### CFB:401866459

**PASS:** WAGERING_AUTHORITY_OFF: Research output; no wager is authorized.; MARKET_VALUE_NOT_EVALUATED: This disclosure layer does not qualify a price or betting edge.; PREDICTIVE_QUALIFICATION_NOT_ASSESSED: Disclosures do not establish predictive qualification.; PARENT_WARNING: TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM; PARENT_WARNING: CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED; PARENT_WARNING: FBS_VS_FBS_ONLY; PARENT_WARNING: NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM; PARENT_WARNING: NO_WAGERING_AUTHORITY; PARENT_WARNING: VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION; PARENT_WARNING: ROSTER:ACQUIRE_REQUIRED; PARENT_WARNING: FULL_ROSTER_IMPACTS_NOT_APPLIED

**Model versus market:** REVIEWED_NONMARKET_FEATURE_PATH. Historical Elo, scoring EWMAs, rest, neutral-site/home advantage and conference features.

- Simulation independence: MARKET_BLIND_NUMERIC_V2_DECLARED; RECEIPT_VERIFICATION_REQUIRED
- Downstream quotes are benchmarks or contract thresholds; changing a line changes the event being priced.
- Source-path attribution only; artifact lineage and predictive validation are not certified.

Winner and separate margin point estimate; selected total head unavailable.

This row declares the separate numeric-v2 procedure introduced after the legacy seed audit. The embedded-payload counterexample remains a legacy.v1 finding; this display does not authenticate the numerical receipt or grant predictive qualification.

**Reported known inputs:**

- None supplied.

**Unknown inputs:**

- availability_evidence: No structured availability disclosure supplied; numerical use is not assessed here.

**Assumptions:**

- None supplied.

**Availability scenarios:** conditional; no availability weights assigned.

- None supplied.

### CFB:401866458

**PASS:** WAGERING_AUTHORITY_OFF: Research output; no wager is authorized.; MARKET_VALUE_NOT_EVALUATED: This disclosure layer does not qualify a price or betting edge.; PREDICTIVE_QUALIFICATION_NOT_ASSESSED: Disclosures do not establish predictive qualification.; PARENT_WARNING: TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM; PARENT_WARNING: CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED; PARENT_WARNING: FBS_VS_FBS_ONLY; PARENT_WARNING: NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM; PARENT_WARNING: NO_WAGERING_AUTHORITY; PARENT_WARNING: VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION; PARENT_WARNING: ROSTER:ACQUIRE_REQUIRED; PARENT_WARNING: FULL_ROSTER_IMPACTS_NOT_APPLIED

**Model versus market:** REVIEWED_NONMARKET_FEATURE_PATH. Historical Elo, scoring EWMAs, rest, neutral-site/home advantage and conference features.

- Simulation independence: MARKET_BLIND_NUMERIC_V2_DECLARED; RECEIPT_VERIFICATION_REQUIRED
- Downstream quotes are benchmarks or contract thresholds; changing a line changes the event being priced.
- Source-path attribution only; artifact lineage and predictive validation are not certified.

Winner and separate margin point estimate; selected total head unavailable.

This row declares the separate numeric-v2 procedure introduced after the legacy seed audit. The embedded-payload counterexample remains a legacy.v1 finding; this display does not authenticate the numerical receipt or grant predictive qualification.

**Reported known inputs:**

- None supplied.

**Unknown inputs:**

- availability_evidence: No structured availability disclosure supplied; numerical use is not assessed here.

**Assumptions:**

- None supplied.

**Availability scenarios:** conditional; no availability weights assigned.

- None supplied.

### CFB:401866460

**PASS:** WAGERING_AUTHORITY_OFF: Research output; no wager is authorized.; MARKET_VALUE_NOT_EVALUATED: This disclosure layer does not qualify a price or betting edge.; PREDICTIVE_QUALIFICATION_NOT_ASSESSED: Disclosures do not establish predictive qualification.; PARENT_WARNING: TOTAL_HEAD_NOT_FITTED_FOR_SELECTED_CFB_ARM; PARENT_WARNING: CURRENT_FCS_INTERNAL_SCHEDULE_COVERAGE_UNVERIFIED; PARENT_WARNING: FBS_VS_FBS_ONLY; PARENT_WARNING: NO_CURRENT_QB_OR_PERSONNEL_TRANSFORM_IN_SELECTED_ARM; PARENT_WARNING: NO_WAGERING_AUTHORITY; PARENT_WARNING: VERSIONED_RNG_IDENTITY_REPAIR_NOT_PREDICTIVE_PROMOTION; PARENT_WARNING: ROSTER:ACQUIRE_REQUIRED; PARENT_WARNING: FULL_ROSTER_IMPACTS_NOT_APPLIED

**Model versus market:** REVIEWED_NONMARKET_FEATURE_PATH. Historical Elo, scoring EWMAs, rest, neutral-site/home advantage and conference features.

- Simulation independence: MARKET_BLIND_NUMERIC_V2_DECLARED; RECEIPT_VERIFICATION_REQUIRED
- Downstream quotes are benchmarks or contract thresholds; changing a line changes the event being priced.
- Source-path attribution only; artifact lineage and predictive validation are not certified.

Winner and separate margin point estimate; selected total head unavailable.

This row declares the separate numeric-v2 procedure introduced after the legacy seed audit. The embedded-payload counterexample remains a legacy.v1 finding; this display does not authenticate the numerical receipt or grant predictive qualification.

**Reported known inputs:**

- None supplied.

**Unknown inputs:**

- availability_evidence: No structured availability disclosure supplied; numerical use is not assessed here.

**Assumptions:**

- None supplied.

**Availability scenarios:** conditional; no availability weights assigned.

- None supplied.



**Diagnostic only. Action authority is OFF. No market/EV layer is attached.**
