# MLB Diagnostic Card — 2026-09-09

Pregame coverage: **100.0%** · Action authority: **OFF**
Prospective grading eligible: **15**

## Point-in-time provenance

- PIT status: **PIT_ALIGNED**
- Requested cutoff: `2026-09-09T08:43:52Z`
- Actual live-fetch vintage proxy: `2026-09-09T08:46:14.556402Z`
- Fetch-to-request delta: **+0h 02m 23s**
- Replay supported: **false**
- Vintage basis: `LIVE_FETCH_TIMESTAMP_PROXY_NOT_SOURCE_EFFECTIVE_TIME`

| Game | Tier | Dose | Winner | Analytic P | Stochastic Sim P | Gap | Divergence | Margin | Total | Grade | Warnings |
|---|---|---:|---|---:|---:|---:|---|---:|---:|---|---|
| Minnesota Twins @ Detroit Tigers | PRIMARY_SHADOW | 0.90 | Detroit Tigers | 56.4% | 54.4% | +1.98 pp | NONE | 0.47527 | 8.46721 | AWAITING | None |
| Toronto Blue Jays @ Athletics | PRIMARY_SHADOW | 0.90 | Toronto Blue Jays | 58.6% | 50.6% | +7.98 pp | MODERATE | -0.75881 | 11.94501 | AWAITING | None |
| St. Louis Cardinals @ San Francisco Giants | PRIMARY_SHADOW | 0.90 | St. Louis Cardinals | 59.0% | 56.2% | +2.84 pp | NONE | -0.64709 | 7.75015 | AWAITING | None |
| Washington Nationals @ San Diego Padres | PRIMARY_SHADOW | 0.90 | Washington Nationals | 54.0% | 52.5% | +1.58 pp | NONE | -0.30568 | 8.81632 | AWAITING | None |
| Texas Rangers @ Seattle Mariners | PRIMARY_SHADOW | 0.90 | Texas Rangers | 55.6% | 52.8% | +2.77 pp | NONE | -0.39099 | 7.51729 | AWAITING | None |
| Cleveland Guardians @ Baltimore Orioles | PRIMARY_SHADOW | 0.90 | Cleveland Guardians | 50.9% | 50.6% | +0.24 pp | NONE | -0.06183 | 7.79611 | AWAITING | None |
| Houston Astros @ Philadelphia Phillies | PRIMARY_SHADOW | 0.90 | Philadelphia Phillies | 59.8% | 55.7% | +4.10 pp | MODERATE | 0.72923 | 8.34563 | AWAITING | None |
| New York Mets @ Miami Marlins | PRIMARY_SHADOW | 0.90 | Miami Marlins | 59.8% | 56.2% | +3.64 pp | NONE | 0.69502 | 7.54294 | AWAITING | None |
| Los Angeles Angels @ Boston Red Sox | PRIMARY_SHADOW | 0.90 | Boston Red Sox | 69.0% | 58.0% | +11.03 pp | SEVERE | 1.4209 | 8.01074 | AWAITING | None |
| Colorado Rockies @ New York Yankees | PRIMARY_SHADOW | 0.90 | New York Yankees | 62.9% | 53.2% | +9.69 pp | SEVERE | 1.08425 | 10.69925 | AWAITING | None |
| Tampa Bay Rays @ Atlanta Braves | BASELINE | 0.80 | Tampa Bay Rays | 51.0% | 48.8% | +2.19 pp | NONE | -0.07641 | 8.39431 | AWAITING | HOME_STARTER_PRIOR_FALLBACK:era,gs,k,bb |
| Arizona Diamondbacks @ Kansas City Royals | PRIMARY_SHADOW | 0.90 | Kansas City Royals | 61.7% | 54.6% | +7.14 pp | MODERATE | 0.94664 | 9.80846 | AWAITING | None |
| Pittsburgh Pirates @ Chicago White Sox | PRIMARY_SHADOW | 0.90 | Pittsburgh Pirates | 52.6% | 49.1% | +3.53 pp | NONE | -0.19461 | 8.49727 | AWAITING | None |
| Chicago Cubs @ Milwaukee Brewers | PRIMARY_SHADOW | 0.90 | Milwaukee Brewers | 62.2% | 56.1% | +6.10 pp | MODERATE | 0.92527 | 8.57209 | AWAITING | None |
| Cincinnati Reds @ Los Angeles Dodgers | PRIMARY_SHADOW | 0.90 | Los Angeles Dodgers | 78.1% | 61.9% | +16.19 pp | CRITICAL | 2.23458 | 8.18626 | AWAITING | None |

**Diagnostic only. Action authority is OFF. No market/EV layer is attached.**
