# MLB Analytic-vs-Simulation Divergence — 2026-09-08

Forecasts analyzed: **15**

| Category | Count |
|---|---:|
| CRITICAL | 3 |
| SEVERE | 0 |
| MODERATE | 5 |
| NONE | 7 |

## Per-game

| Game | Analytic P | Stochastic Sim P | Gap | Category | Margin | Total | Normal-margin candidate |
|---|---:|---:|---:|---|---:|---:|---:|
| Cleveland Guardians @ Baltimore Orioles | 57.8% | 53.4% | +4.37 pp | MODERATE | 0.57 | 8.05 | 54.0% |
| Minnesota Twins @ Detroit Tigers | 59.4% | 54.9% | +4.41 pp | MODERATE | 0.72 | 8.94 | 55.5% |
| Houston Astros @ Philadelphia Phillies | 60.6% | 54.0% | +6.58 pp | MODERATE | -0.87 | 10.24 | 55.2% |
| New York Mets @ Miami Marlins | 59.0% | 57.1% | +1.95 pp | NONE | 0.62 | 7.03 | 55.0% |
| Los Angeles Angels @ Boston Red Sox | 50.4% | 48.0% | +2.43 pp | NONE | -0.03 | 7.54 | 50.3% |
| Colorado Rockies @ New York Yankees | 79.9% | 61.4% | +18.54 pp | CRITICAL | 2.59 | 9.44 | 65.3% |
| Tampa Bay Rays @ Atlanta Braves | 52.0% | 48.1% | +3.90 pp | NONE | -0.16 | 9.73 | 50.9% |
| Arizona Diamondbacks @ Kansas City Royals | 52.2% | 51.6% | +0.58 pp | NONE | 0.16 | 8.45 | 51.2% |
| Pittsburgh Pirates @ Chicago White Sox | 59.0% | 52.7% | +6.30 pp | MODERATE | 0.67 | 8.35 | 55.1% |
| Chicago Cubs @ Milwaukee Brewers | 73.4% | 59.0% | +14.43 pp | CRITICAL | 1.87 | 8.82 | 62.9% |
| Washington Nationals @ San Diego Padres | 50.6% | 50.0% | +0.61 pp | NONE | -0.05 | 8.07 | 50.4% |
| Texas Rangers @ Seattle Mariners | 58.2% | 56.7% | +1.51 pp | NONE | -0.55 | 6.69 | 54.7% |
| Toronto Blue Jays @ Athletics | 64.3% | 58.1% | +6.15 pp | MODERATE | -1.31 | 12.54 | 57.4% |
| St. Louis Cardinals @ San Francisco Giants | 54.0% | 52.8% | +1.19 pp | NONE | -0.29 | 8.02 | 52.2% |
| Cincinnati Reds @ Los Angeles Dodgers | 76.2% | 60.3% | +15.90 pp | CRITICAL | 2.02 | 7.97 | 64.1% |

## Correlations with absolute divergence

| Feature | Pearson r |
|---|---:|
| projected_total | +0.266 |
| abs_projected_margin | +0.954 |
| favorite_analytic_p | +0.951 |
| gamma_dispersion_mean | -0.254 |
| starter_workload_variance | +0.388 |
| bullpen_share_mean | +0.235 |
| park_factor | +0.203 |
| extra_inning_probability | -0.294 |

## Multivariable debug regression

Status: **DEBUG_SAMPLE_ONLY** · n=15 · R²=0.9122089903945302

> This is a debugging sample. Do not treat one slate as calibration evidence.

## Ablation interpretation

- A isolates fixed-rate independent Poisson.
- B adds Gamma run-rate overdispersion while holding starter workload fixed.
- C is explicitly unavailable because the current engine has no shared run-environment component.
- D adds starter-workload randomness.
- E is the full current engine; it currently equals D because bullpen sequencing is not modeled.

**No sportsbook prices or EV calculations are included.**
