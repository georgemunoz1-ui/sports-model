# MLB Diagnostic Card — 2026-09-08

Pregame coverage: **100.0%** · Action authority: **OFF**
Prospective grading eligible: **15**

## Point-in-time provenance

- PIT status: **PIT_ALIGNED**
- Requested cutoff: `2026-09-08T20:08:57Z`
- Actual live-fetch vintage proxy: `2026-09-08T20:09:52.711976Z`
- Fetch-to-request delta: **+0h 00m 56s**
- Replay supported: **false**
- Vintage basis: `LIVE_FETCH_TIMESTAMP_PROXY_NOT_SOURCE_EFFECTIVE_TIME`

| Game | Tier | Dose | Winner | Analytic P | Stochastic Sim P | Gap | Divergence | Margin | Total | Grade | Warnings |
|---|---|---:|---|---:|---:|---:|---|---:|---:|---|---|
| Cleveland Guardians @ Baltimore Orioles | PRIMARY_SHADOW | 0.90 | Baltimore Orioles | 57.8% | 53.4% | +4.37 pp | MODERATE | 0.56621 | 8.05161 | AWAITING | None |
| Minnesota Twins @ Detroit Tigers | PRIMARY_SHADOW | 0.90 | Detroit Tigers | 59.4% | 54.9% | +4.41 pp | MODERATE | 0.71701 | 8.93699 | AWAITING | None |
| Houston Astros @ Philadelphia Phillies | PRIMARY_SHADOW | 0.90 | Houston Astros | 60.6% | 54.0% | +6.58 pp | MODERATE | -0.86853 | 10.23547 | AWAITING | None |
| New York Mets @ Miami Marlins | PRIMARY_SHADOW | 0.90 | Miami Marlins | 59.0% | 57.1% | +1.95 pp | NONE | 0.61541 | 7.02633 | AWAITING | None |
| Los Angeles Angels @ Boston Red Sox | PRIMARY_SHADOW | 0.90 | Los Angeles Angels | 50.4% | 48.0% | +2.43 pp | NONE | -0.0294 | 7.54142 | AWAITING | None |
| Colorado Rockies @ New York Yankees | PRIMARY_SHADOW | 0.90 | New York Yankees | 79.9% | 61.4% | +18.54 pp | CRITICAL | 2.59003 | 9.44387 | AWAITING | None |
| Tampa Bay Rays @ Atlanta Braves | PRIMARY_SHADOW | 0.90 | Tampa Bay Rays | 52.0% | 48.1% | +3.90 pp | NONE | -0.15528 | 9.72532 | AWAITING | None |
| Arizona Diamondbacks @ Kansas City Royals | BASELINE | 0.80 | Kansas City Royals | 52.2% | 51.6% | +0.58 pp | NONE | 0.16179 | 8.44759 | AWAITING | AWAY_STARTER_PRIOR_FALLBACK:era,gs,k,bb |
| Pittsburgh Pirates @ Chicago White Sox | PRIMARY_SHADOW | 0.90 | Chicago White Sox | 59.0% | 52.7% | +6.30 pp | MODERATE | 0.67026 | 8.35166 | AWAITING | None |
| Chicago Cubs @ Milwaukee Brewers | PRIMARY_SHADOW | 0.90 | Milwaukee Brewers | 73.4% | 59.0% | +14.43 pp | CRITICAL | 1.87164 | 8.82258 | AWAITING | None |
| Washington Nationals @ San Diego Padres | PRIMARY_SHADOW | 0.90 | Washington Nationals | 50.6% | 50.0% | +0.61 pp | NONE | -0.04561 | 8.06863 | AWAITING | None |
| Texas Rangers @ Seattle Mariners | BASELINE | 0.80 | Texas Rangers | 58.2% | 56.7% | +1.51 pp | NONE | -0.54712 | 6.68652 | AWAITING | HOME_STARTER_PRIOR_FALLBACK:era,gs,k,bb |
| Toronto Blue Jays @ Athletics | PRIMARY_SHADOW | 0.90 | Toronto Blue Jays | 64.3% | 58.1% | +6.15 pp | MODERATE | -1.30741 | 12.53601 | AWAITING | None |
| St. Louis Cardinals @ San Francisco Giants | PRIMARY_SHADOW | 0.90 | St. Louis Cardinals | 54.0% | 52.8% | +1.19 pp | NONE | -0.28758 | 8.0166 | AWAITING | None |
| Cincinnati Reds @ Los Angeles Dodgers | PRIMARY_SHADOW | 0.90 | Los Angeles Dodgers | 76.2% | 60.3% | +15.90 pp | CRITICAL | 2.02494 | 7.96966 | AWAITING | None |

**Diagnostic only. Action authority is OFF. No market/EV layer is attached.**
